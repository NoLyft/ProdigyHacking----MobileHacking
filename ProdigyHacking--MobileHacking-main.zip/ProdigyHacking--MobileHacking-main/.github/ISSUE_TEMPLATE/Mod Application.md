---
name: Mod Application
about: Looking for mods to help make accounts/answer questions. 

---

(put in an "X" in the parentheses for your answer)

1. Do you want to be a mod?

yes ()

No ()

2. do you have past experience with being a mod for other things (github,websites etc.) 

yes ()

No ()

3. What makes you more suitable over other candidates?

delete this and type here


