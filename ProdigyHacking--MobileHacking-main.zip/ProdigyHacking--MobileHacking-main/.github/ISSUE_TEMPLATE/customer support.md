---
name: customer support Application
about: Looking for to help me with the customer support side of things. 

---

Why should I choose you over other candidates?:

What makes you more suitable over other candidates?:

Give me an email that I can use to contact me-this is needed so I can review your application. (my email is calebthehufflepuff@gmail.com):
