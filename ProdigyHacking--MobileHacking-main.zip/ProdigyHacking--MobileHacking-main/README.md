<details>
  <summary>About the people to made the hacks!</summary>
 <hr />
 Currently, manually hacking Prodigy Math Game on mobile devices is not possible to do manually, which is why I have created this station. All hacked accounts are made using hacks created by
            <a href="http://github.com/Prodigy-Hacking/ProdigyMathGameHacking/">ProdigyMathGameHacking</a>. <b>An order of any amount of accounts are free</b>
          .  The ProdigyMathGameHacking Code of Conduct does apply. My motiviation is the same as ProdigyMathGameHacking:
            <blockquote style="border-left: 5px solid #ddd; padding-left: 10px;">
                We're not trying to break the game because we're evil. We just wanted to help Prodigy become more secure, but they've ignored our emails and our requests to talk.
                <br/>
                Because of that we're just publicly showing hacks! That, and it's also just fun ;)
                <br/>
                All of our hacks are open source, and free. No paywalls, no ads, and no Patreon.
            </blockquote>

</details>

<details>

<summary>How to request a account!</summary>

If you have any questions, email
            <a href="mailto:calebthehufflepuff@gmail.com">calebthehufflepuff@gmail.com</a> - if you'd like to make an order, please click the button below.
            <br/><br/>
            If you'd like to learn more about this project, see <a href="https://github.com/CRobbins0867/ProdigyHacking--MobileHacking/discussions/23">here</a>.
        </div>
        
   <a href="https://github.com/CRobbins0867/ProdigyHacking--MobileHacking/issues/new?assignees=&labels=&template=account-request-.md"
        class="blockButton">Click here to request a account</a>
    
   </body>
</html>

</details>

<details>
  <summary>Collaborators!</summary>
 
 ## Current Collaborators

- [0BunnySenpai0](https://github.com/0BunnySenpai0)
  






## Retired Collaborators
- [PrinceHughJass](https://github.com/PrinceHughJass)
- [hostedposted](https://github.com/hostedposted)
- [irhrhd](https://github.com/irhrhd)
- [PixelWolf1](https://github.com/PixelWolf1)
- [Prodigy-hack-yt](https://github.com/Prodigy-hack-yt)
  

</details>




    Credit Goes to @NameIsA for the original idea And The PMGH Team for supplying the hacks
 
